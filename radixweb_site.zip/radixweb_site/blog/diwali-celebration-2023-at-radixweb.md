---
title: Diwali 2023 at Radixweb: Celebrating Joy and Togetherness
url: https://radixweb.com/blog/diwali-celebration-2023-at-radixweb
category: blog
---

[Life at Radixweb](/insights/life-at-radix "Life at Radixweb")

# Lighting Up the Festive Vibe at Radixweb: Diwali 2023 Celebrations

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

Published : Nov 9, 2023

As the sun dipped below the horizon, ushering in the Festival of Lights, Radixians gathered to illuminate their surroundings and their hearts. The office buzzed with excitement, and the aroma of delectable Diwali delights wafted through the air. It was a day that radiated joy and togetherness – a day to celebrate Diwali 2023 at Radixweb.

**But before that, watch this heartwarming Diwali video, that showcases the bond and togetherness we share at Radixweb.**

[![Abhishek Biswas](/images/loader.gif)](/author/abhishek-biswas "Abhishek Biswas")

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

![LinkedIn](https://s3.ap-south-1.amazonaws.com/stage.radixweb.com/linkedin_dark_8184803581.png)[LinkedIn](https://www.linkedin.com/in/abhishekbiswas2211/)

Content Marketing Lead

|

9 Years of Experience 

Abhishek Biswas is the Content Marketing Lead at Radixweb who focuses on brand storytelling, thought leadership, and company culture narratives. He specializes in creating engaging content that highlights Radixweb’s people, values, and innovation journey while connecting with audiences through authentic storytelling. 

[View All Posts](/author/abhishek-biswas)

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=ff72f7c5-66ef-4cbd-b244-f7d88b74962d&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=8a21be97-4cc7-4e58-a023-cc9cd7f6be0b&pt=Diwali%202023%20at%20Radixweb%3A%20Celebrating%20Joy%20and%20Togetherness&tw_document_href=https%3A%2F%2Fradixweb.com%2Fblog%2Fdiwali-celebration-2023-at-radixweb&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
