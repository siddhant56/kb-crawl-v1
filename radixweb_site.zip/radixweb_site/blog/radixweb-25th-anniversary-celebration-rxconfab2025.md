---
title: RxConfab 2025: 25 Years of Radixweb’s Legacy in Tech Excellence
url: https://radixweb.com/blog/radixweb-25th-anniversary-celebration-rxconfab2025
category: blog
---

# RXConfab 2025: 25 Years of Tech Excellence and Trust

Abhishek Biswas

Published: Jul 25, 2025

ON THIS PAGE

  1. Confab 2025 Theme: Tech Excellence and Trust
  2. RXConfab 2025 - The Silver Jubilee Celebration
  3. From Where We Started
  4. Where We Are Headed Now
  5. Expressing Our Gratitude



Some milestones transcend numbers. They become legacies, etched in purpose, grit, and the quiet but firm power of trust. For us at Radixweb, completing 25 years isn’t just a timeline. It’s a living testament to two pillars that have shaped our every stride: Tech Excellence and Trust.

And what better way to [celebrate this legacy than through RXConfab 2025](/radixweb-anniversary "celebrate this legacy than through RXConfab 2025") \- an event that wasn’t just about marking a date but reflecting on the spirit that fuels us, the journey that shaped us, and the aspirations that will carry us forward.

Get a glimpse of the electric atmosphere at RxConfab 2025:

## 2025 Theme: Tech Excellence and Trust 

Each year, RXConfab reflects a theme that aligns with our strategic vision. This year, as we stood proudly at the quarter-century mark, the theme chose itself:

**Tech Excellence and Trust**

Today, technology outpaces itself by the minute. In such a world, it is only trust that remains the rare constant. It’s the unwavering belief that the solutions we build aren’t just advanced. They’re responsible, resilient, and rooted in impact.

### Relive the Celebration

If you missed the live energy of RxConfab 2025, you can get the essence of the evening on our social media.

## The Silver Jubilee Experience – RXConfab 2025 

Our 25-year milestone deserved an event of equal grandeur. And RXConfab 2025 delivered exactly that and more.

The atmosphere was electric with pride, nostalgia, and anticipation. Radixians, leadership, long-term clients and partners gathered to celebrate not just a company, but the journey.

**The Journey Showcase**

We opened with a visual journey that traced Radixweb’s then and now. From our beginning in 2000 to today’s expansive, global presence - it was a story of perseverance.

Check out the video here:

### Candid Leadership Fireside

One of the most heartwarming moments was the candid talk between our CEO, Mr. Divyesh Patel, and COO, Mr. Dharmesh Acharya. They pulled back the curtain on their journey and recounted a time when they had to import the latest PHP 3.0 manual from the US, compared to today’s instant digital access.

![RxConfab Leadership Discussions](https://d2ms8rpfqc4h24.cloudfront.net/1_image_c4890c40e4.jpg)

They joked about how countless cups of chai (tea) have fueled countless lines of code and brainstorming sessions. Because sometimes caffeine fuels the code!

This authentic conversation struck a chord, reminding everyone that behind every milestone is a story of hustle, humility, and human connection.

### Family Messages that Touched Hearts

As if the evening wasn’t emotional enough, a surprise video rolled in. Families of Divyesh Patel, Dharmesh Acharya, and Pratik Mistry (EVP - Technology Consulting) sent their heartfelt congratulations to the Radixweb family.

What started as smiles soon turned into misty eyes across the room. The message was clear: Radixweb’s journey isn’t just professional. It’s deeply personal, driven by the collective efforts of families, teams, and leaders.

### Cultural Performances and Team Spirit

In true Radixweb tradition, our people brought the stage alive with:

  * Vibrant cultural dances
  * Soulful music performances
  * Funny skits that hilariously captured life in tech
  * A guest stand-up comedian who had everyone laughing at our shared “techie” quirks



![RxConfab 2025 Highlights](https://d2ms8rpfqc4h24.cloudfront.net/2_image_13a3a12db1.jpg)

But the highlight was a group activity designed to bring out Radixweb’s spirit of teamwork. A lively, participative experience that reminded us that collaboration is our ultimate strength.

### Sweet Celebrations: Cakes, Cupcakes, and Surprises

No celebration is complete without cake, but at Radixweb, we take it a step further. While the leadership led the grand Silver Jubilee cake cutting, every attendee received a cupcake. A symbolic gesture that made every member of the Radixweb family feel included in the celebration. No matter where they stood in the room. It was moments like these that added layers of warmth to the evening.

### Our Story, in a Rap!

As part of the celebration, our team also created a special rap song that captured Radixweb’s 25-year journey in a fun, lyrical format. It was a lighthearted tribute to our growth, culture, and tech roots and had everyone smiling with its catchy lines and beats.

Watch the video here:

## The Foundation of Our 25-Year Journey 

A 25-year milestone in the tech space—where change is constant—isn't a small feat. And we achieved this feat with conscious and consistent choices, guided by our unwavering values like:

  * Success isn’t defined by deliverables but by the sustained growth of our clients.
  * Continuous learning and skill-building is a priority. That's how we keep our teams perpetually future-ready.
  * Choosing the harder right over the easier wrong. Integrity anchors all our projects and partnerships.



And as COO Dharmesh Acharya put it:

> _There were times where we could have taken the shortcut, the easy way out. But we never did. We did things the right way, With integrity and honesty. That's how we have moved above mediocrity towards technical excellence and how we gained the trust that our employees, clients, and partners place in us._

## The Future: Tech Excellence and Trust 

As we step into the next chapter, our guiding principles remain unchanged. In fact, we are doubling down on our promise of being tech guides and partners from our clients, not just tech yes-men. In CEO, Divyesh's words:

> _I've always told my team this: We are not here to sell fancy dreams to our clients. We are here to bring realistic dreams to life with technology. And if something isn't right or realistic, we are not afraid of saying it. We don't jump on technology trends and follow the herd. Understanding, observing, and doing what is right - what is required - is what makes us a trusted partner, not just a tech vendor._

> _Thank You for 25 Years of Trust_ _Our Silver Jubilee isn’t just a company celebration. It’s a tribute to every client, partner, Radixian, and family member who believed in us.__Now that we are done partying and celebrating the past 25 years, we are ready for the next 25. Because when Tech Excellence and Trust are your compass, you’re always just getting started.__Want to be a part of what we are building next?[Check out our current openings here](/current-openings "Check out our current openings here") and join the Radix fam._

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=e5c1094b-f52c-4cb2-aad0-f48d4c57085a&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=9a8d8381-9100-4105-871c-872f2bb086d7&pt=RxConfab%202025%3A%2025%20Years%20of%20Radixweb%E2%80%99s%20Legacy%20in%20Tech%20Excellence&tw_document_href=https%3A%2F%2Fradixweb.com%2Fblog%2Fradixweb-25th-anniversary-celebration-rxconfab2025&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
