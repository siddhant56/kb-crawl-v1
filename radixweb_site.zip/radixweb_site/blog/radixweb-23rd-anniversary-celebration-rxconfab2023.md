---
title: Radixweb’s 23rd Anniversary RXConfab2023 Celebration
url: https://radixweb.com/blog/radixweb-23rd-anniversary-celebration-rxconfab2023
category: blog
---

[Life at Radixweb](/insights/life-at-radix "Life at Radixweb")

# RXConfab 2023 Radixweb’s Foundation Day Celebrations

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

Published : Jul 27, 2023

July 21 marks a special day for everyone at Radixweb – it’s our foundation day. This year we completed 23 successful years of innovation and excellence. Radixweb has achieved great heights in these 23 years. And this milestone won’t have been possible without the constant efforts of our people, who are also the backbone of composing this fantastic journey.

We Radixians never miss a chance to celebrate any occaasion, and make it memorable. On the 21st July 2023, vibe could be felt as we entered our workplace – everyone was excited about the grand celebration. Because it’s the day our team across departments come together and enjoy to their fullest.

In a journey spanning 23 years, we as an organization have soared to remarkable heights, earning an esteemed reputation for our unwavering [commitment to excellence](/blog/celebrating-23-years-of-client-success-stories "commitment to excellence") across all tech domains. Our steadfast dedication to excellence has become synonymous with our name. If you remember, our pledge for this year is ‘[Vision Customer Xcellence](/blog/radixweb-celebrating-23-years-of-fostering-tech-confidence "Vision Customer Xcellence")’ – where we ensure we deliver the best services to customers by upskilling our people.

[![Abhishek Biswas](/images/loader.gif)](/author/abhishek-biswas "Abhishek Biswas")

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

![LinkedIn](https://s3.ap-south-1.amazonaws.com/stage.radixweb.com/linkedin_dark_8184803581.png)[LinkedIn](https://www.linkedin.com/in/abhishekbiswas2211/)

Content Marketing Lead

|

9 Years of Experience 

Abhishek Biswas is the Content Marketing Lead at Radixweb who focuses on brand storytelling, thought leadership, and company culture narratives. He specializes in creating engaging content that highlights Radixweb’s people, values, and innovation journey while connecting with audiences through authentic storytelling. 

[View All Posts](/author/abhishek-biswas)

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=05274910-9451-4577-beab-556d78aa7378&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=7eb16e67-e793-4ce1-b017-6f2c00e14582&pt=Radixweb%E2%80%99s%2023rd%20Anniversary%20RXConfab2023%20Celebration&tw_document_href=https%3A%2F%2Fradixweb.com%2Fblog%2Fradixweb-23rd-anniversary-celebration-rxconfab2023&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
