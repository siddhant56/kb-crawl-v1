---
title: Radixweb Christmas Celebration 2024: A Joyous Festivity
url: https://radixweb.com/blog/christmas-celebration-2024-at-radixweb
category: blog
---

[Life at Radixweb](/insights/life-at-radix "Life at Radixweb")

# A Joyous Christmas at Radixweb: When Festive Cheer Meets New Year Readiness

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

Published : Dec 26, 2024

 _**Quick Rundown:** Let’s get into Radixweb’s Christmas celebration! From dazzling decors to secret santa surprises, and our excitement for 2025, see how we celebrated the season while gearing up for a brand-new year ahead. Read on to experience more!_

This Christmas, Radixweb didn’t just celebrate - we lived the festive spirit in every sense. Walking into our [**HQ, Ekyarth**](/new-office-launch-ekyarth "HQ, Ekyarth"), you could feel the sparkle of dazzling lights, vibrant wreaths, and the festive cheer filling the air.

Obviously, it wasn’t just the decor but the atmosphere that our people created. The air was alive with Radixians’ excitement, laughter, and the warmth of togetherness.

[![Abhishek Biswas](/images/loader.gif)](/author/abhishek-biswas "Abhishek Biswas")

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

![LinkedIn](https://s3.ap-south-1.amazonaws.com/stage.radixweb.com/linkedin_dark_8184803581.png)[LinkedIn](https://www.linkedin.com/in/abhishekbiswas2211/)

Content Marketing Lead

|

9 Years of Experience 

Abhishek Biswas is the Content Marketing Lead at Radixweb who focuses on brand storytelling, thought leadership, and company culture narratives. He specializes in creating engaging content that highlights Radixweb’s people, values, and innovation journey while connecting with audiences through authentic storytelling. 

[View All Posts](/author/abhishek-biswas)

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=afb50ecf-681e-42af-93d0-c8ee58c34f10&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=f213255e-10a3-45c4-a9ff-2938140462a4&pt=Radixweb%20Christmas%20Celebration%202024%3A%20A%20Joyous%20Festivity&tw_document_href=https%3A%2F%2Fradixweb.com%2Fblog%2Fchristmas-celebration-2024-at-radixweb&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
