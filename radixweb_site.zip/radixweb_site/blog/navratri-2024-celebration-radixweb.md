---
title: Celebrating RXNavratri 2024: Dance, Culture and Team Spirit at Radixweb
url: https://radixweb.com/blog/navratri-2024-celebration-radixweb
category: blog
---

[Life at Radixweb](/insights/life-at-radix "Life at Radixweb")

# RXNavratri 2024: Radixians Make the Most of the Festive Season

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

Published : Oct 10, 2024

All work and no play makes Jack a dull boy!

And we Radixians aren’t any Jack, so we tap on our keyboards in sync, until we reach the ground and match our steps to upbeat music. We are talking about the festival of Nine Nights – Navratri, when the whole of Radixweb gathers around for some party-peppy music, grooving to the beats of drums and reveling in the spirited dance form that we call ‘garba’.

And with the families joining into our festive fervour, the colours of this festival shone brighter for **#RXNavratri2024**.

[![Abhishek Biswas](/images/loader.gif)](/author/abhishek-biswas "Abhishek Biswas")

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

![LinkedIn](https://s3.ap-south-1.amazonaws.com/stage.radixweb.com/linkedin_dark_8184803581.png)[LinkedIn](https://www.linkedin.com/in/abhishekbiswas2211/)

Content Marketing Lead

|

9 Years of Experience 

Abhishek Biswas is the Content Marketing Lead at Radixweb who focuses on brand storytelling, thought leadership, and company culture narratives. He specializes in creating engaging content that highlights Radixweb’s people, values, and innovation journey while connecting with audiences through authentic storytelling. 

[View All Posts](/author/abhishek-biswas)

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=9f0ca732-5430-416f-8b29-9db39e1838b9&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=71414ad5-6315-4805-83d9-dfc918aa3fa2&pt=Celebrating%20RXNavratri%202024%3A%20Dance%2C%20Culture%20and%20Team%20Spirit%20at%20Radixweb&tw_document_href=https%3A%2F%2Fradixweb.com%2Fblog%2Fnavratri-2024-celebration-radixweb&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
