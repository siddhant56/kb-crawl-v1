---
title: Radixian Celebrated Navaratri 2023 
url: https://radixweb.com/blog/navratri-2023-celebration-radixweb
category: blog
---

[Life at Radixweb](/insights/life-at-radix "Life at Radixweb")

# Navratri 2023 Celebration: Radixians Grooving at Garba Tunes

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

Published : Oct 23, 2023

Yes, it is that time of the year! When the cold breeze had just knocked on the door. The winter is just waiting for the shore to be called upon. And the nights are lit up by the people to cherish the festival of Nine Nights (Navratri).

With family, the charm of a festival gets more vibrant. So this time, team Radixweb invited spouses of every Radixian to celebrate **#RXNavratri2023**.

**Prior to proceeding, take a moment to immerse yourself in our exclusive #RXNavratri2023 Celebrations video**

[![Abhishek Biswas](/images/loader.gif)](/author/abhishek-biswas "Abhishek Biswas")

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

![LinkedIn](https://s3.ap-south-1.amazonaws.com/stage.radixweb.com/linkedin_dark_8184803581.png)[LinkedIn](https://www.linkedin.com/in/abhishekbiswas2211/)

Content Marketing Lead

|

9 Years of Experience 

Abhishek Biswas is the Content Marketing Lead at Radixweb who focuses on brand storytelling, thought leadership, and company culture narratives. He specializes in creating engaging content that highlights Radixweb’s people, values, and innovation journey while connecting with audiences through authentic storytelling. 

[View All Posts](/author/abhishek-biswas)

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=4e151050-e69e-44f4-b803-099b3a901307&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=aec221c1-93b7-41f2-9937-6586391f01c2&pt=Radixian%20Celebrated%20Navaratri%202023&tw_document_href=https%3A%2F%2Fradixweb.com%2Fblog%2Fnavratri-2023-celebration-radixweb&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
