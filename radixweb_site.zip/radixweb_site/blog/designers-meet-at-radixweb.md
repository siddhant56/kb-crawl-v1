---
title: Designers Meet with Sandskriti at Radixweb
url: https://radixweb.com/blog/designers-meet-at-radixweb
category: blog
---

[Life at Radixweb](/insights/life-at-radix "Life at Radixweb")

# A Memorable Meetup: Bringing Design Community Under One Roof

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

Published : May 11, 2023

Radixweb recently hosted an event on Designers Meet in collaboration with Sandskriti, a well-known community for designers. The event was held at Radixweb’s corporate house and witnessed a massive turnout from the design industry.

Over 300 designers from various industries and backgrounds became part of this grand event, hosted at [Radixweb house](/our-infrastructure "Radixweb house") – Ekyarth.

The event aimed to bring together designers from different backgrounds to share their experiences, learn from each other, and create new connections within the industry. It was a great platform for designers to showcase their work, network with other professionals, and gain insights into the latest trends and technologies in the field.

[![Abhishek Biswas](/images/loader.gif)](/author/abhishek-biswas "Abhishek Biswas")

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

![LinkedIn](https://s3.ap-south-1.amazonaws.com/stage.radixweb.com/linkedin_dark_8184803581.png)[LinkedIn](https://www.linkedin.com/in/abhishekbiswas2211/)

Content Marketing Lead

|

9 Years of Experience 

Abhishek Biswas is the Content Marketing Lead at Radixweb who focuses on brand storytelling, thought leadership, and company culture narratives. He specializes in creating engaging content that highlights Radixweb’s people, values, and innovation journey while connecting with audiences through authentic storytelling. 

[View All Posts](/author/abhishek-biswas)

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=4008aa4b-7696-469b-bee3-c88e1a4f51e3&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=4d25901b-9b0a-4fb0-89e9-a7d16cbeb630&pt=Designers%20Meet%20with%20Sandskriti%20at%20Radixweb&tw_document_href=https%3A%2F%2Fradixweb.com%2Fblog%2Fdesigners-meet-at-radixweb&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
