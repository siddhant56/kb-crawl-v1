---
title: Diwali 2024 at Radixweb: Colors, Festivity, and Team Bonding
url: https://radixweb.com/blog/diwali-celebration-2024-at-radixweb
category: blog
---

[Life at Radixweb](/insights/life-at-radix "Life at Radixweb")

# Diwali 2024 At Radixweb: Lighting up the Way for a Brighter Future

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

Published : Oct 30, 2024

The dusk above us, lights twinkling over the slightly chilly wind, a broad canvas of colours, and a legacy of over two decades illuminating our path for a future - bigger and brighter!

We are officially in the season of celebrations and after one of the most successful sessions of [RXNavratri](/blog/navratri-2024-celebration-radixweb "RXNavratri"), we are now swooning over the festival of lights, Diwali - the brightest of celebrations we held this year. Watch this video to get a glimpse of what the day looked like:

To say the least, Diwali 2024 at Radixweb was one of the most gleeful celebrations of the year. Watch this video to get a glimpse of what the day looked like:

[![Abhishek Biswas](/images/loader.gif)](/author/abhishek-biswas "Abhishek Biswas")

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

![LinkedIn](https://s3.ap-south-1.amazonaws.com/stage.radixweb.com/linkedin_dark_8184803581.png)[LinkedIn](https://www.linkedin.com/in/abhishekbiswas2211/)

Content Marketing Lead

|

9 Years of Experience 

Abhishek Biswas is the Content Marketing Lead at Radixweb who focuses on brand storytelling, thought leadership, and company culture narratives. He specializes in creating engaging content that highlights Radixweb’s people, values, and innovation journey while connecting with audiences through authentic storytelling. 

[View All Posts](/author/abhishek-biswas)

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=dabf7563-efb1-4cad-a93f-c722169063a1&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=f7d34a0e-8aad-4c57-babb-94cb7cff5dd5&pt=Diwali%202024%20at%20Radixweb%3A%20Colors%2C%20Festivity%2C%20and%20Team%20Bonding&tw_document_href=https%3A%2F%2Fradixweb.com%2Fblog%2Fdiwali-celebration-2024-at-radixweb&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
