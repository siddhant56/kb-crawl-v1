---
title: Radixweb’s 24th Anniversary Celebration
url: https://radixweb.com/blog/radixweb-24th-anniversary-celebration-rxconfab2024
category: blog
---

[Life at Radixweb](/insights/life-at-radix "Life at Radixweb")

# RXConfab2024: A Celebration of Radixweb’s 24 Years of Growth, Innovation, and Impact

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

Published : Jul 25, 2024

July, a month outlined in Radixweb’s accounts as a testament to another milestone, reflection, and reinvention. This year, we completed 24 successful years in the business.

Twenty-four years of pushing boundaries, breaking new moulds, and delivering the true impact of technology with real results – a legacy that demanded a celebration as extraordinary as the achievements themselves. And that’s exactly what happened at #RXConfab.

At **RXConfab2024** , the air tingled with excitement as Radixians gathered to revel in this momentous occasion. It was a kaleidoscope of joy and camaraderie as our teams across departments came together to bask in the festivities and forge unforgettable memories. It was a time when every Radixian reflected on how far we have come and recognized the brilliance of ideologies that have shaped our story.

[![Abhishek Biswas](/images/loader.gif)](/author/abhishek-biswas "Abhishek Biswas")

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

![LinkedIn](https://s3.ap-south-1.amazonaws.com/stage.radixweb.com/linkedin_dark_8184803581.png)[LinkedIn](https://www.linkedin.com/in/abhishekbiswas2211/)

Content Marketing Lead

|

9 Years of Experience 

Abhishek Biswas is the Content Marketing Lead at Radixweb who focuses on brand storytelling, thought leadership, and company culture narratives. He specializes in creating engaging content that highlights Radixweb’s people, values, and innovation journey while connecting with audiences through authentic storytelling. 

[View All Posts](/author/abhishek-biswas)

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=9fda04ce-1b8c-430f-aa71-9a0d063cb9b4&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=711615fa-7776-4fdc-adc1-976781d73e4f&pt=Radixweb%E2%80%99s%2024th%20Anniversary%20Celebration&tw_document_href=https%3A%2F%2Fradixweb.com%2Fblog%2Fradixweb-24th-anniversary-celebration-rxconfab2024&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
