---
title: Story of an Aspiring Coder Who Found Her Way at Radixweb
url: https://radixweb.com/blog/journey-of-prakruti-at-radixweb
category: blog
---

[Life at Radixweb](/insights/life-at-radix "Life at Radixweb")

# From Dreams to Reality, How Prakruti Started Her Coding Journey

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

Published : Dec 11, 2023

 _“I want to gain more and more knowledge until I reach the stage of life where I can manage my own team and let them grow with my support.” -_ Prakruti Joshi

This is Prakruti’s long-term goal as she aspires to work and gain advanced insights in coding. Working at Radixweb has allowed her to learn and acquire insights into various technologies and more brilliant coding techniques from her experienced colleagues.

After completing her higher secondary education, she pursued computer engineering due to her passion for logical problem-solving and development. Her curiosity was constantly growing, and she was intrigued by how the world was becoming increasingly digital, with information and services at the fingertips.

[![Abhishek Biswas](/images/loader.gif)](/author/abhishek-biswas "Abhishek Biswas")

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

![LinkedIn](https://s3.ap-south-1.amazonaws.com/stage.radixweb.com/linkedin_dark_8184803581.png)[LinkedIn](https://www.linkedin.com/in/abhishekbiswas2211/)

Content Marketing Lead

|

9 Years of Experience 

Abhishek Biswas is the Content Marketing Lead at Radixweb who focuses on brand storytelling, thought leadership, and company culture narratives. He specializes in creating engaging content that highlights Radixweb’s people, values, and innovation journey while connecting with audiences through authentic storytelling. 

[View All Posts](/author/abhishek-biswas)

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=2ab7c599-cd9f-4631-aa25-f9b105c46ff2&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=2d115226-de11-4137-a5d6-f23bfcba47c4&pt=Story%20of%20an%20Aspiring%20Coder%20Who%20Found%20Her%20Way%20at%20Radixweb&tw_document_href=https%3A%2F%2Fradixweb.com%2Fblog%2Fjourney-of-prakruti-at-radixweb&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
