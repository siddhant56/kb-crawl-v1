---
title: Women’s Day 2023 Celebrations at Radixweb
url: https://radixweb.com/blog/radixweb-celebrates-womens-day-2023
category: blog
---

[Life at Radixweb](/insights/life-at-radix "Life at Radixweb")

# Celebrating Women's Day 2023: Embracing the Equity

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

Published : Mar 13, 2023

At Radixweb, we believe that the success of any organization is due to its people. This Women’s Day, we wanted to ensure that our female teammates felt appreciated and empowered. For this, we organized a “**Self Defence Workshop** ” conducted by Ujjwal Jaiswal, a Martial Arts Coach since 2001.

The workshop’s main goal was to empower the women of Radixweb with the skills and techniques they need to protect themselves in case of any danger. During the workshop, the participants were taught self-defense techniques, practical exercises for strength and confidence, and special escaping techniques.

The workshop not only provided the women of Radixweb with the necessary skills to defend themselves but also instilled a sense of confidence and pride in them. This was further enhanced when the ladies were presented with surprise gifts and chocolates.

[![Abhishek Biswas](/images/loader.gif)](/author/abhishek-biswas "Abhishek Biswas")

[Abhishek Biswas](/author/abhishek-biswas "Abhishek Biswas")

![LinkedIn](https://s3.ap-south-1.amazonaws.com/stage.radixweb.com/linkedin_dark_8184803581.png)[LinkedIn](https://www.linkedin.com/in/abhishekbiswas2211/)

Content Marketing Lead

|

9 Years of Experience 

Abhishek Biswas is the Content Marketing Lead at Radixweb who focuses on brand storytelling, thought leadership, and company culture narratives. He specializes in creating engaging content that highlights Radixweb’s people, values, and innovation journey while connecting with audiences through authentic storytelling. 

[View All Posts](/author/abhishek-biswas)

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=028c048e-935d-4796-a739-5956b9f7d8d1&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=9a4689d1-44ab-4503-af1e-ece241cceaec&pt=Women%E2%80%99s%20Day%202023%20Celebrations%20at%20Radixweb&tw_document_href=https%3A%2F%2Fradixweb.com%2Fblog%2Fradixweb-celebrates-womens-day-2023&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
