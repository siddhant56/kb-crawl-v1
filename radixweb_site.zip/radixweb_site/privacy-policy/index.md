---
title: Privacy Policy - Radixweb
url: https://radixweb.com/privacy-policy
category: privacy-policy
---

Radixweb prioritizes the data privacy and digital security of its visitors. Our Privacy Policy serves as a comprehensive guide on the collection of information, its use and disclosure when you visit us or use our services.

Radixweb collects and uses your personal data to provide, tailor and improve its service quality. By using our services, it will be considered that you agree to the collection and use of your information as stated in this policy.

## Data Collection

Radixweb fetches and stores information that is required to grant you access to our complete website to the extent that this statement defines.

**Information That We Collect from You -**

_Information received directly:_

We receive an assortment of data automatically when you use our service ie. our website and our pages. This may include:

  * The IP address of your device
  * Type and version of browser you are using
  * The date and time of your visit
  * The pages of our service visited by you and time spent
  * Location, referral source, navigation blueprint during your visit
  * Unique device identifiers
  * Other diagnostic data



When you access our service using a mobile device, we collect the following data:

  * The type of mobile device used by you
  * The IP address and unique ID of your mobile device
  * The OS, type of mobile browser used by you



When you ask for a formal appointment, call back, customer support, sign up for any event/passes you email us or fill up the 'Contact Us' form, you actively share your contact information with us. We will store your:

  * Name
  * Contact number
  * Email address
  * Location
  * Any associated data for further correspondence.



We also access and store your personal data of the above-mentioned nature when you apply to our vacancies.

Note: We occasionally receive data from third-party sources when you upload your resume to job portals or when someone recommends your profile to our HR for vacancies.

_Information we receive indirectly:_

We indirectly receive certain information when you:

  * Enquire about services or sign-up forms through authentication services like Google, LinkedIn
  * Interact with us through our social media pages



## Data Processing

Radixweb does not use your data unethically. We process your information only on the following grounds:

_**We have your consent for storing and using your data:**_

We at Radixweb, strongly believe in delivering superior digital experiences. We leverage tracking technologies like cookies on our website to collate visitor data. This is used as crucial elements of market research when we research for the behavioural patterns and priorities of our visitors.

The goal of making use of cookies is to build an accurate analytical roadmap for weighing the true impact of our marketing efforts by aligning them with user expectations and strengthening future marketing blueprints.

Radixweb also stores your data if you are a subscriber of our social media channels. We use your personal data and preferences to push for you relevant newsletters, emails and promotional materials as per your history of preferences.

We also store personal and contact details of employees that apply to us for open positions. We also maintain a database for candidates that express the interest of working with us, to ensure that we reach out to them when their preferred opportunity opens up.

_**It serves our business interests within permissible limits:**_

  * For replying to your website queries or contact forms to arrange a reply/ consultation with experts as per your need
  * For ensuring our website security, protecting our intellectual property rights and for preventing fraudulent activities.



_**We are bound by a legal obligation:**_

If we are asked by any court of law or are legally bound to answer questions about your project, we may have to disclose the blueprint of your intellectual property (project ideas, vision).

## When Do We Use Your Data?

We make use of your personal data only for the following cases:

  * **For you:** To contact you for informing about updates, functionalities, products, contracted services, security updates; to provide you news and promotional offers about services similar to what you already use; to manage and reply to your queries and requests.
  * **For business transfers:** We may use your personal data as company assets in case of mergers, reorganization, restructuring, divestiture, transfer and sale of assets, acquisition in case of bankruptcy, liquidation or proceedings of similar nature.
  * **Between location offices:** Radixweb is a continuously expanding business with strategic office locations around the globe. We share you data between these location offices for serving our business interests better while adhering to regional and global data transfer regulations.
  * **To clients, agencies, auditors, supervisory authorities:** We may use your data as references and testimonials for our skills and expertise for getting projects, certificates and awards.
  * **For specific legal requirements:** We may disclose your personal data in good faith if we have to comply with any legal obligation, protect and defend the rights of our business, investigate or prevent illegal activities with the service.



Consent to Data Processing:

By furnishing your personal information to the website, you imply that you fully understand and unambiguously consent to the collection and processing of such information in India and/or any other country.

Child Protection and Privacy:

Radixweb doesn't provide service to anyone under the legal age of 15. We knowingly refrain from storing personally identifiable information for anyone under this age. In case we identify storing the personal information of a minor without formal parental consent, we remove the information from our servers.

Deleting Your Personal Data:

Radixweb offers you full autonomy for the right to delete information that we have collected and hold about you.

You are free to update, change and delete any information at any point of time by either directly contacting your account manager, or clicking [right here](/contact-us "right here").

## Our Cookie Policy

Like all other professional websites, our website uses cookies. This information is about what information they fetch, how we use the information and why we may need to store such cookies.

You will also find information on how you can reject these cookies. However, rejecting cookies can also lead to breaking the functionalities of certain elements on this website, and some parts may not be made available to you.

_**What are website cookies?**_

Cookies are small text files that get stored on your device when you visit any website. They store and retain your login details, preferences and browsing patterns to deliver enhanced browsing experiences. These also help in delivering secured browsing by identifying website users and preventing unauthorized logins.

_**How do we use cookies on our website?**_

When you visit our website for the first time, we issue pop-up alerts that give you the option to accept or reject cookies.

Radixweb uses two kinds of cookies to help you experience more personalized and interactive browsing on our website:

  * Session cookies that expire when you close the browser
  * Persistent cookies that stay on your device until manually cleared



 _**What kind of data do we collect with cookies?**_

We majorly collect the following data with the help of cookies:

  * **Login credentials:** Username and password to keep you logged in
  * **User Preferences:** Language settings, theme choices, custom layouts
  * **Browsing History:** User activity - page visits, actions taken on the site
  * **Session Information:** All interaction made during a particular visit; deleted when the browser is closed



**How to Disable Cookies?**

You just need to adjust the cookies setting on your respective browser.

**Security**

Securing all personal and non-personal information associated with our visitors and participants is a high priority for us. We use secure forms of communication for such data. However, due to the open communication nature of the internet, no data transmission can be guaranteed to be totally secure. Thus, we cannot guarantee that any communication between you and the website will be free from any kind of unauthorized access by third parties and be completely secure.

**Sale or Change of Control**

The information collected on the website is an asset of Radixweb and in the event of sale or change of control it will be treated like other assets and transferred accordingly.

**Links to Other Websites**

Our website may contain links to other websites or other websites may reference and link to our website. However, Radixweb has no control or does not influence the privacy policy of such other websites and is in no way responsible for the privacy practices or content of such other websites. We, therefore, encourage our visitors and participants to read the privacy statements of every website that collects personal information.

**Acceptance of Policy**

By visiting this website or by receiving services from this website, you are signifying your acceptance of our privacy policy. If you disagree with any of the terms, please do not use our website or our services. We also reserve the rights to change, modify, add, or remove portions from this policy at any time, at our discretion, by simply posting such change, update, or modification on the website. Your continued use of our site after the changes to the policy terms implies your acceptance of these terms.

## Recognized by Top Industry Platforms

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

[View All Awards](/our-awards "View All Awards")

[View All Awards](/our-awards "View All Awards")

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=f7de1549-c896-4a44-a0a5-d509326ae527&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=88a88db2-4e7a-4b09-8721-a6294e537b24&pt=Privacy%20Policy%20-%20Radixweb&tw_document_href=https%3A%2F%2Fradixweb.com%2Fprivacy-policy&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
