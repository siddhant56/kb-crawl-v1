---
title: Radixweb Software Technology Leadership Team - Radixweb
url: https://radixweb.com/leadership
category: employees
---

## Leadership That Delivers Trust 

**Since 2000, we have been razor-focused on innovating responsibly with tech and delivering the right business value. We’ve built a legacy of trust where businesses trust our judgement and strategy.**

_A business maestro with innovation obsession, driving business transformation with a deep-seated market understanding and foundational knowledge._

Areas of Focus:

![Dharmesh Acharya COO at Radixweb](/images/loader.gif)

![Pratik Mistry – EVP of Technology Consulting](/images/loader.gif)

![Ajay Ojha – Chief Architect](/images/loader.gif)

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=0659acad-9779-4f0b-9dfe-925b26b27cd5&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=4596bd93-87ca-43ed-90f5-766025a57427&pt=Radixweb%20Software%20Technology%20Leadership%20Team%20-%20Radixweb&tw_document_href=https%3A%2F%2Fradixweb.com%2Fleadership&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
