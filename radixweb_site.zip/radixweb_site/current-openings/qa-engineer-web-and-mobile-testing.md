---
title: QA Engineer – Web & Mobile Testing (Playwright + TypeScript)
url: https://radixweb.com/current-openings/qa-engineer-web-and-mobile-testing
category: current-openings
---

### Number Of openings :

: 2

### Experience :

: 2 to 4 Years

### Qualification :

: BE/B.Tech/ME/M. Tech/MSc-IT/MCA

Apply Now

**Shift Timing: UK Shift – 2:00 PM to 11:00 PM (IST)**

### How you should be?

We are seeking a **QA Engineer** with **end-to-end quality ownership** for web and mobile applications. The ideal candidate will have hands-on experience with **Playwright using TypeScript** , strong manual testing skills, and the ability to collaborate closely with **UK-based clients** in a high-delivery environment.

Apply Now

  * [Trainee Software Engineer](/current-openings/trainee-software-engineer-net "Trainee Software Engineer")
  * [Business Development Executive](/current-openings/business-development-executive "Business Development Executive")
  * [Business Analyst](/current-openings/business-analyst "Business Analyst")
  * [Associate - Social Media Executive](/current-openings/associate-social-media-executive "Associate - Social Media Executive")
  * [Associate Content Marketer](/current-openings/content-marketer "Associate Content Marketer")
  * [Associate Template Designer](/current-openings/associate-template-designer "Associate Template Designer")
  * [Senior Software Engineer – Python and Generative AI](/current-openings/senior-software-engineer-python-ai "Senior Software Engineer – Python and Generative AI")
  * [Head - Customer Success](/current-openings/head-customer-success-manager "Head - Customer Success")
  * [Web Engineer](/current-openings/web-engineer "Web Engineer")
  * [Senior Software Engineer - Python/React](/current-openings/senior-software-engineer-python-and-react "Senior Software Engineer - Python/React")
  * [QA Engineer – Web & Mobile Testing](/current-openings/qa-engineer-web-and-mobile-testing "QA Engineer – Web & Mobile Testing")
  * [Senior AI/ML Engineer (LLM & Agentic Systems)](/current-openings/senior-ai-ml-engineer "Senior AI/ML Engineer \(LLM & Agentic Systems\)")
  * [Senior AI/ML Engineer (Data Science & MLOps)](/current-openings/senior-ai-ml-engineer-data-science "Senior AI/ML Engineer \(Data Science & MLOps\)")
  * [Data Analyst / BI Developer](/current-openings/data-analyst-bi-developer "Data Analyst / BI Developer")



![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=cc37b266-9580-4ef6-8725-f85e7d19dbd9&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=011dc6c3-9310-48ae-b4a5-6e82c0952f58&pt=QA%20Engineer%20%E2%80%93%20Web%20%26%20Mobile%20Testing%20\(Playwright%20%2B%20TypeScript\)&tw_document_href=https%3A%2F%2Fradixweb.com%2Fcurrent-openings%2Fqa-engineer-web-and-mobile-testing&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
