---
title: Trainee Software Engineer – (.NET / PHP / QA / Nodejs / Python / Reactjs) - Radixweb
url: https://radixweb.com/current-openings/trainee-software-engineer-net
category: current-openings
---

### Number Of openings :

: 50

### Experience :

: Freshers

### Qualification :

: BE/B.Tech/ME/M.Tech/MSc/MCA (IT/CE/CS) – 2025-26 Batch

Apply Now

### Must be in prior

  * The candidate must do online registration for the online assessment test
  * The candidate share the soft copy CV



Apply Now

  * [Trainee Software Engineer](/current-openings/trainee-software-engineer-net "Trainee Software Engineer")
  * [Business Development Executive](/current-openings/business-development-executive "Business Development Executive")
  * [Business Analyst](/current-openings/business-analyst "Business Analyst")
  * [Associate - Social Media Executive](/current-openings/associate-social-media-executive "Associate - Social Media Executive")
  * [Associate Content Marketer](/current-openings/content-marketer "Associate Content Marketer")
  * [Associate Template Designer](/current-openings/associate-template-designer "Associate Template Designer")
  * [Senior Software Engineer – Python and Generative AI](/current-openings/senior-software-engineer-python-ai "Senior Software Engineer – Python and Generative AI")
  * [Head - Customer Success](/current-openings/head-customer-success-manager "Head - Customer Success")
  * [Web Engineer](/current-openings/web-engineer "Web Engineer")
  * [Senior Software Engineer - Python/React](/current-openings/senior-software-engineer-python-and-react "Senior Software Engineer - Python/React")
  * [QA Engineer – Web & Mobile Testing](/current-openings/qa-engineer-web-and-mobile-testing "QA Engineer – Web & Mobile Testing")
  * [Senior AI/ML Engineer (LLM & Agentic Systems)](/current-openings/senior-ai-ml-engineer "Senior AI/ML Engineer \(LLM & Agentic Systems\)")
  * [Senior AI/ML Engineer (Data Science & MLOps)](/current-openings/senior-ai-ml-engineer-data-science "Senior AI/ML Engineer \(Data Science & MLOps\)")
  * [Data Analyst / BI Developer](/current-openings/data-analyst-bi-developer "Data Analyst / BI Developer")



![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=e8006ad9-d82c-445f-926e-f1a94ca502a6&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=3311f80f-afb0-4595-8158-09a0ea8791c6&pt=Trainee%20Software%20Engineer%20%E2%80%93%20\(.NET%20%2F%20PHP%20%2F%20QA%20%2F%20Nodejs%20%2F%20Python%20%2F%20Reactjs\)%20-%20Radixweb&tw_document_href=https%3A%2F%2Fradixweb.com%2Fcurrent-openings%2Ftrainee-software-engineer-net&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
