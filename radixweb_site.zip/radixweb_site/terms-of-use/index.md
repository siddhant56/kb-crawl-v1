---
title: Terms of Use - Radixweb
url: https://radixweb.com/terms-of-use
category: terms-of-use
---

Welcome to the website of Radixweb. Use of this website and information distributed with relation to this website is offered to you on acceptance of the Terms of Use and Privacy Policy of Radixweb. Your use of this website or of any content present in any and all areas of the website implies your acknowledgement and acceptance of the Terms of Use, Privacy Policy and other notices posted on the website. In case of disagreement, do not use our website, services, and information provided on the site.

_**Radixweb reserves the right to make any amendment to these Terms and Conditions at any point of time without prior notice.**_

## Copyright and Usage of Intellectual Property

The content published on this website namely, text, graphics, logos, trademarks are the property of Radixweb and are protected by copyright, trademark, patent, and/or other intellectual property laws. Any unauthorized usage of these may breach such laws and lead to legal repercussions. In addition to this, Radixweb is in no way responsible for the third party logos present on the website. The copyright of such logos is purely third parties’ concern. You are liable to agree not to copy, republish, download, transmit, modify, rent, loan, sell, distribute, license, or create differential works based on the site, its material, or its services. You are liable to accept this service as explicitly authorized herein.

The images used on this website are stock photographs purchased from stock photography website. Radixweb does not claim copyright ownership to these photographs.

_**All material on this website is Copyright @ 2009 RADIXWEB, India. All other trademarks and trade names are the properties of their respective owners.**_

## Usage of the Website

By using the website, you effectively agree to follow and be bound by the terms and conditions mentioned hereunder concerning the use of the website. You agree not to copy, modify, reproduce, republish, upload, transmit, post, or distribute any text, images, graphics, video, and audio used on this website for any public or commercial purpose. Unauthorized use of any material appearing on this website may violate copyright, trademark, and other applicable laws resulting in civil or criminal penalties. All rights not expressly granted herein are reserved. You would not submit, send, or otherwise transmit any illegal, noxious, crude, insulting, molesting, pornographic, or otherwise obnoxious material of any kind. You would further not use any contact information and email addresses found on this website to send unsolicited junk mails.

This website may contain links to other websites. Radixweb is in no way responsible for the contents of these third party sites and your access to such sites via these links is solely at your own risk. Radixweb is not responsible for the privacy practices of such websites as well as for third party opinions expressed on or through our website.

Radixweb reserves the right to terminate your access to the website at any time for any reason. We also reserve the right to monitor your access to the website. Radixweb shall be in no way held responsible for any damage caused to your computer system or loss of data resulting from your use and download of any content material, or information from this website.

## Usage of Software Services

The website offers products and services on an “as is” basis and “as available” basis. The software services are provided under a legally binding business agreement. The terms and conditions of this agreement shall be communicated to you via personally identifiable information. An expressed consent to the terms and conditions contained in this agreement shall make it legally binding on both the parties.

## Service Notification

All information and material made available on this website is provided on “as is” basis and “as available” basis only. Radixweb expressly disclaims all warranties of any kind, whether expressed or implied, including, but not limited to, the implied warranties of merchantability, fitness for a particular purpose, and non-infringement of the rights of third parties. Radixweb reserves the right to modify, terminate access to, or discontinue temporarily or permanently any part or the entire website or any information published on the website without prior notification. The provisions of disclaimer of warranty, accuracy of information, and indemnification shall survive any termination.

## Personal Information Policy

Radixweb follows ethical business practices and providers full protection for personally identifiable information. Please read our Privacy Policy carefully for full disclosure of details.

## Disclaimer

The information contained on the website has been collected from sources believed to be reliable. However, the website may contain technical or other mistakes, inaccuracies, or typography errors. Radixweb denounces all claims as to the accuracy, completeness or adequacy of such information. The information provided on this website should not be construed as IT consultancy, legal, tax, accounting or any other professional advice or service.

Radixweb makes no warranties, expressed or implied, including without limitation, those of merchantability and fitness for a particular purpose, with respect to any information, data, statements or products made available on the website. The use of services offered on this website and any other usage of any material through this website is done at your own discretion and risk. In no event shall Radixweb be held liable for damages of any kind, including without limitation, direct, incidental, or consequential damages arising out of the use of or inability to use Radixweb website or any information provided on the website. You agree to indemnify, defend, and absolve Radixweb from any losses, expenses, damages and costs, including reasonable attorney fees, arising out of or relating to any misuse of the content and services of the site by the user.

Radixweb does not claim that the website shall meet your requirements and will be available on an uninterrupted, timely, secure, and error free basis. We do not claim that the results obtained from the use of this website or any services offered through the website will be accurate.

Radixweb further reserves the right to modify the material, services offered, and pricing and descriptions of products and services listed herein at any point of time without prior notification.

## Limitation of Liability

Radixweb is not liable to you or other third parties for any kind of damages whatsoever including loss of data and profits, even if Radixweb has been advised of the possibility of such damages in any condition, or limitation, or negligence. For jurisdictions that do not allow limitation or exclusion of liability some of the above mentioned limitations may not apply to you.

## Contact

You may contact Radixweb’s business development team to know more about the terms and conditions of the website. You are hereby requested to make all your communication directly to Radixweb.

## Recognized by Top Industry Platforms

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

![](/images/loader.gif)

[View All Awards](/our-awards "View All Awards")

[View All Awards](/our-awards "View All Awards")

![](https://t.co/1/i/adsct?bci=4&dv=Asia%2FCalcutta%26en-US%26Google%20Inc.%26MacIntel%26127%261280%26800%268%2624%261280%26800%260%26na&eci=3&event=%7B%7D&event_id=79d2b3fd-f4c4-4bac-8442-e45eb4a05854&integration=gtm&p_id=Twitter&p_user_id=0&pl_id=b9781e10-e10c-4939-a65f-32aebf2a4801&pt=Terms%20of%20Use%20-%20Radixweb&tw_document_href=https%3A%2F%2Fradixweb.com%2Fterms-of-use&tw_iframe_status=0&tw_pid_src=2&twpid=tw.1779556045443.188498004268236342&txn_id=oesjk&type=javascript&version=2.3.53)

We're offline

Leave a message

 __
